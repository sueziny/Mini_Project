## Encore WebProject 4조_골라조


## [SRS](https://github.com/EncoreWebProject4/WebProject/wiki/02_SRS)


## [UseCaseDiagram](https://github.com/EncoreWebProject4/WebProject/wiki/03_Usecase-Diagram)


## [DB Modeling](https://github.com/EncoreWebProject4/WebProject/wiki/05_DB-Modeling)


## [Front UI](https://www.figma.com/file/t0e6q0jOrxtnGzL7RSpYdC/%EA%B3%A8%EB%9D%BC%EC%A1%B0_ver_0)

## [Business Logic](https://github.com/EncoreWebProject4/WebProject/wiki/04_Business-Logic)















### [회의록](https://github.com/EncoreWebProject4/WebProject/issues)
