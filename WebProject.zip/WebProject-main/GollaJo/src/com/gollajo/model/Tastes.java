package com.gollajo.model;

public class Tastes {
	private int tasteIdx;
	private String taste;
}
